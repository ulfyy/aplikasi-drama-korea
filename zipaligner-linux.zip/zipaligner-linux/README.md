zipaligner
==========

Quick signing/zipaligning tool for [Linux](https://github.com/aureljared/zipaligner/zipball/linux)/[Windows](https://github.com/aureljared/zipaligner/zipball/windows)
